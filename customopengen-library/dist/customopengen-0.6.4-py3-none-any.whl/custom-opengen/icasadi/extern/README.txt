C files auto-generated using CasADi are stored here

In particular, in this folder you will find:

- `auto_casadi_cost.c`
- `auto_casadi_grad.c`
- `auto_casadi_mapping_f1.c`
- `auto_casadi_mapping_f2.c`
- `casadi_memory.h`
- `interface.c`